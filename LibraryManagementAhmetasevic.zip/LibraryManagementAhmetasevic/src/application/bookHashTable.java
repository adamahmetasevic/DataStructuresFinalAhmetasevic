package application;


public class bookHashTable {
    private BookLinkedList[] table;
    private int capacity;

    public bookHashTable(int capacity) {
        this.capacity = capacity;
        table = new BookLinkedList[capacity];
    }

    private int hash(String key) {
        int hashValue = 0;
        for (int i = 0; i < key.length(); i++) {
            hashValue = 31 * hashValue + key.charAt(i);
        }
        return hashValue % capacity;
    }

    public void addBook(String title, String author, String isbn, String year) {
    	Book book = new Book(title,author,isbn,year);
        int index = hash(book.getIsbn());
        if (table[index] == null) {
            table[index] = new BookLinkedList();
        }
        table[index].addBook(book);
    }

    public void deleteBook(String isbn) {
        int index = hash(isbn);
        if (table[index] != null) {
            Book book = table[index].searchBook(isbn);
            if (book != null) {
                table[index].deleteBook(book);
            }
        }
    }

    public Book searchBook(String isbn) {
        int index = hash(isbn);
        if (table[index] != null) {
            return table[index].searchBook(isbn);
        }
        return null;
    }

	public int getCapacity() {
		return capacity;
	}

	public BookLinkedList[] getTable() {
		return table;
	}

}
